package com.furenqiang.system.service;

import com.furenqiang.system.entity.Test;

import java.util.List;

public interface TestService {

    public List<Test> getTest();
}
