package com.furenqiang.system.service;

import com.furenqiang.system.common.ResponseResult;

public interface SysMenuService {

    ResponseResult getMenuTree();

}
